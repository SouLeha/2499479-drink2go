/* в этот файл добавляет скрипты*/
import './swiper.js';
import './mobile-menu.js';
