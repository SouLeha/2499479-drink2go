
const headerToggle = document.querySelector('.main-nav__toggle');

headerToggle.addEventListener('click', closeOrOpenMenu);
